package br.com.eive.apisharepoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSharepointApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiSharepointApplication.class, args);
	}

}
